__all__ = ['animal', 'human']
#init에서 *을 쓸수는 있지만 추천은 안함
#import *도 추천은 안함
#여기서 정의해주면 연동가능

