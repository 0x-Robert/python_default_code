from lesson_package.tools import utils

#..은 안쓰는것을 추천

def sing():
    return 'g1@@#$21453245'

def cry():
    return utils.say_twice('deasfdsaf')


