#from lesson_package.tools import utils
from ..tools import utils
#..은 안쓰는것을 추천

def sing():
    return 'sing'

def cry():
    return utils.say_twice('cry')

